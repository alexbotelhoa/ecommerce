CREATE PROCEDURE sp_addresses_save(IN pidaddress   INT, IN pidperson INT, IN pdesaddress VARCHAR(128),
                                   IN pdesnumber   VARCHAR(16), IN pdescomplement VARCHAR(32),
                                   IN pdesdistrict VARCHAR(32), IN pdescity VARCHAR(32), IN pdesstate VARCHAR(32),
                                   IN pdescountry  VARCHAR(32), IN pdeszipcode CHAR(8))
  BEGIN

	IF pidaddress > 0 THEN
		
		UPDATE tb_addresses
        SET
			idperson = pidperson,
            desaddress = pdesaddress,
            desnumber = pdesnumber,
            descomplement = pdescomplement,
			desdistrict = pdesdistrict,
            descity = pdescity,
            desstate = pdesstate,
            descountry = pdescountry,
            deszipcode = pdeszipcode
		WHERE idaddress = pidaddress;
        
    ELSE
		
		INSERT INTO tb_addresses (idperson, desaddress, desnumber, descomplement, desdistrict, descity, desstate, descountry, deszipcode)
        VALUES(pidperson, pdesaddress, pdesnumber, pdescomplement, pdesdistrict, pdescity, pdesstate, pdescountry, pdeszipcode);
        
        SET pidaddress = LAST_INSERT_ID();
        
    END IF;
    
    SELECT * FROM tb_addresses WHERE idaddress = pidaddress;

END;
