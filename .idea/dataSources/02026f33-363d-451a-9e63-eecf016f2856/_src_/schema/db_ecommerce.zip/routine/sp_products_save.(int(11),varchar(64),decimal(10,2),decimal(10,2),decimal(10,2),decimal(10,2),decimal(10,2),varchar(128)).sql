CREATE PROCEDURE sp_products_save(IN pidproduct INT, IN pdesproduct VARCHAR(64), IN pvlprice DECIMAL(10, 2),
                                  IN pvlwidth   DECIMAL(10, 2), IN pvlheight DECIMAL(10, 2),
                                  IN pvllength  DECIMAL(10, 2), IN pvlweight DECIMAL(10, 2), IN pdesurl VARCHAR(128))
  BEGIN
	
	IF pidproduct > 0 THEN
		
		UPDATE tb_products
        SET 
			desproduct = pdesproduct,
            vlprice = pvlprice,
            vlwidth = pvlwidth,
            vlheight = pvlheight,
            vllength = pvllength,
            vlweight = pvlweight,
            desurl = pdesurl
        WHERE idproduct = pidproduct;
        
    ELSE
		
		INSERT INTO tb_products (desproduct, vlprice, vlwidth, vlheight, vllength, vlweight, desurl) 
        VALUES(pdesproduct, pvlprice, pvlwidth, pvlheight, pvllength, pvlweight, pdesurl);
        
        SET pidproduct = LAST_INSERT_ID();
        
    END IF;
    
    SELECT * FROM tb_products WHERE idproduct = pidproduct;
    
END;
